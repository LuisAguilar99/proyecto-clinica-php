<?php
session_start();
if (!isset($_SESSION['idUsuario'])) {
    header("Location: login.php");
} else {
    $idUsuarioIndex = $_SESSION['idUsuario'];
    $empleadoIndex = $_SESSION['idEmpleado'];
    $usuarioIndex = $_SESSION['usuario'];
    $tipoAdminIndex = $_SESSION['tipoAdmin'];
    $dadoBajaIndex = $_SESSION['dadoBaja'];
}
include('./funciones/conecta.php');
?>
<html lang="es">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <title>Administración</title>

    <!-- Bootstrap core CSS -->
    <script src="./js/jquery-3.6.0.min.js"></script>
    <link href="./css/bootstrap.css" rel="stylesheet" crossorigin="anonymous">
    <link href="./css/jquery.dataTables.min.css" type="text/css" rel="stylesheet">
    <script type="text/javascript" src="./js/jquery.dataTables.min.js"></script>

    <!-- Favicons -->
    <!-- <link rel="apple-touch-icon" href="/docs/5.1/assets/img/favicons/apple-touch-icon.png" sizes="180x180"> -->

    <style>
        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }
    </style>


    <!-- Custom styles for this template -->
    <link href="./css/dashboard.css" rel="stylesheet">
    <style type="text/css">
        /* Chart.js */

        @keyframes chartjs-render-animation {
            from {
                opacity: .99
            }

            to {
                opacity: 1
            }
        }

        .chartjs-render-monitor {
            animation: chartjs-render-animation 1ms
        }

        .chartjs-size-monitor,
        .chartjs-size-monitor-expand,
        .chartjs-size-monitor-shrink {
            position: absolute;
            direction: ltr;
            left: 0;
            top: 0;
            right: 0;
            bottom: 0;
            overflow: hidden;
            pointer-events: none;
            visibility: hidden;
            z-index: -1
        }

        .chartjs-size-monitor-expand>div {
            position: absolute;
            width: 1000000px;
            height: 1000000px;
            left: 0;
            top: 0
        }

        .chartjs-size-monitor-shrink>div {
            position: absolute;
            width: 200%;
            height: 200%;
            left: 0;
            top: 0
        }

        .oculto {
            display: none;
        }


        label {
            display: inline-block;
        }

        .cuadros {
            border: 1px solid grey;
            border: 10.5px outset #E5E8E8;
            border-radius: 5%;
            padding: 15px;
        }

        .cuadros-secc {
            padding: 15px;
            border: 1px inset #E5E8E8;
        }

        .datosCargados {
            border: 2.5px solid #E5E8E8;
            background-color: #F4F6F7;
            padding: 0.375rem 0.75rem;
            font-size: 1rem;
            font-weight: 400;
            line-height: 1.5;
        }
    </style>
    <script>
        $(document).ready(function() {            
            for (var i = 1; i < 4; i++) {
                $('#myTable' + i).DataTable({
                    "lengthMenu": [
                        [4, 25, 50, -1],
                        [4, 25, 50, "All"]
                    ],
                    // "paging": false,
                    "info": false
                });
            }
        });
        function ocultarSeccion(seccion) {
            var listSeccion = ["#nuevoCliente", "#adeudoCliente", "#actualizarCliente", "#mostrarCliente", "#seccionDefault", "#formCorrecto"];
            for (var i = 0; i < listSeccion.length; i++) {
                if (listSeccion[i] == seccion) {
                    $(listSeccion[i]).removeClass("oculto");
                } else {
                    $(listSeccion[i]).addClass("oculto");
                }

            }
        }

        function asignarBaja() {
            var id_usuario = $('#id_usuario').val();
            if (id_usuario != '') {
                $.ajax({
                    url: './funciones/asignarBajaUsuario.php',
                    type: 'post',
                    dataType: 'text',
                    data: 'id_usuario=' + id_usuario,
                    success: function(res) {
                        if (res) {
                            alert('La baja fue asignada');
                            location.reload();
                        } else {
                            alert('El usuario no existe');
                        }

                        return true;
                    },
                    error: function(res) {
                        alert('Error al conectar al servidor...');
                        return false;
                    }
                });
            } else {
                alert("Inserta el id del usuario");
                return false;
            }
        }

        function quitarBaja() {
            var id_usuario = $('#id_usuario').val();
            if (id_usuario != '') {
                $.ajax({
                    url: './funciones/quitarBajaUsuario.php',
                    type: 'post',
                    dataType: 'text',
                    data: 'id_usuario=' + id_usuario,
                    success: function(res) {
                        if (res) {
                            alert('La baja fue removida');
                            location.reload();
                        } else {

                            alert('El usuario no existe');
                        }
                        return true;
                    },
                    error: function(res) {
                        alert(res);
                        alert('Error al conectar al servidor...');
                        return false;
                    }
                });
            } else {
                alert("Inserta el id del usuario");
                return false;
            }
        }

        function agregarDatos() {
            var id_empleado = $('#id_empleado').val();
            var usuario = $('#usuario').val();
            var password = $('#password').val();
            var tipo_admin = $('#tipo_admin').val();
            if (id_empleado != '' && usuario != '' && password != '' && tipo_admin != '') {
                $.ajax({
                    url: './funciones/agregarUsuarioBase.php',
                    type: 'post',
                    data: 'id_empleado=' + id_empleado + '&usuario=' + usuario + '&password=' + password + '&tipo_admin=' + tipo_admin,
                    success: function(res) {
                        if (res) {
                            alert('Datos agregados');
                            ocultarSeccion('#formCorrecto');
                            limpiarForm();
                        } else {
                            alert('Datos NO agregados');
                        }
                        return true;
                    },
                    error: function(res) {
                        console.log(res);
                        alert('Error al conectar al servidor...');
                        return false;
                    }
                });
            } else {
                alert("Inserta el id del cliente");
                return false;
            }
        }

        function limpiarForm() {
            $('#id_empleado').val('');
            $('#usuario').val('');
            $('#password').val('');
            $('#tipo_admin').val('');
        }

        function cargarDatosAct() {
            var id_usuario_act = $('#id_usuario_act').val();
            if (id_usuario_act != '') {
                $.ajax({
                    url: './funciones/obtenerUsuario.php',
                    type: 'post',
                    data: 'id_usuario=' + id_usuario_act,
                    success: function(res) {
                        if ($.trim(res) != '0') {
                            var datos = res.split("|");
                            $('#id_empleado_act').val(datos[0]);
                            $('#tipo_admin_act').val(datos[1]);
                            $('#usuario_act').val(datos[2]);
                            $('#password_act').val($.trim(datos[3]));
                            $('#modalActualizar').modal('show');
                        } else {
                            limpiarForm();
                            alert("No se encontro cliente con este ID");
                        }
                        return true;
                    },
                    error: function(res) {
                        console.log(res);
                        alert('Error al conectar al servidor...');
                        return false;
                    }
                });
            } else {
                alert("Inserta el id del cliente");
                return false;
            }
        }

        function actualizarDatos() {
            var id_usuario_act = $('#id_usuario_act').val();
            var id_empleado_act = $('#id_empleado_act').val();
            var usuario_act = $('#usuario_act').val();
            var password_act = $('#password_act').val();
            var tipo_admin_act = $('#tipo_admin_act').val();
            // alert(apellidoCliente);
            if (id_usuario_act != '' && id_empleado_act != '' && usuario_act != '' && password_act != '' && tipo_admin_act != '') {
                $.ajax({
                    url: './funciones/actualizarDatosUsuario.php',
                    type: 'post',
                    data: 'id_usuario_act=' + id_usuario_act + '&id_empleado_act=' + id_empleado_act + '&usuario_act=' + usuario_act + '&password_act=' + password_act + '&tipo_admin_act=' + tipo_admin_act,
                    success: function(res) {
                        if (res) {
                            alert('Datos Actualizados');
                            limpiarForm();
                            cerrarModal();
                        } else {
                            alert('Datos NO actualizados');
                            cerrarModal();
                        }
                        return true;
                    },
                    error: function(res) {
                        console.log(res);
                        alert('Error al conectar al servidor...');
                        return false;
                    }
                });
            } else {
                alert("Inserta el id del cliente");
                return false;
            }
        }

        function cerrarModal() {
            $('#modalActualizar').modal('hide');
        }

        function refrescar() {
            $("#myDivTable3").load("./listarClientesInfo.php");
            console.log('actualicion');
        }
    </script>
</head>

<body>

    <?php include("./navbar/navbar.php"); ?>

    <div class="container-fluid">
        <div class="row">
            <?php include("./navbar/navbar_seccion.php"); ?>
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Panel de administración - Administración Usuarios</h1>
                </div>
            </main>
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <!-- Modal -->
                <div class="row">
                    <div class="col">
                        <div class="container">
                            <div class="row">
                                <div class="col cuadros" style="text-align: center;">
                                    <input type="image" src="./sgv/nuevo_cliente.svg" width="40%" onclick="ocultarSeccion('#nuevoCliente');">
                                    <label>
                                        <h5>Agregar nuevo usuario</h5>
                                    </label>
                                </div>
                                <div class="col cuadros" style="text-align: center;">
                                    <input type="image" src="./sgv/baja_usuario.svg" width="40%" onclick="ocultarSeccion('#adeudoCliente');">
                                    <label>
                                        <h5>Asignar baja usuario</h5>
                                    </label>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col cuadros" style="text-align: center;">
                                    <input type="image" src="./sgv/actualizar_cliente.svg" width="40%" onclick="ocultarSeccion('#actualizarCliente');">
                                    <label>
                                        <h5>Actualizar datos usuario</h5>
                                    </label>
                                </div>
                                <div class="col cuadros" style="text-align: center;">
                                    <input type="image" src="./sgv/lista_cliente.svg" width="40%" onclick="ocultarSeccion('#mostrarCliente');">
                                    <label>
                                        <h5>Mostrar usuarios</h5>
                                    </label>
                                </div>
                            </div>
                            <div class="row cuadros">
                                <div class="col " style="text-align: right; align-items: center;">
                                <input type="image" src="./sgv/info_usuario.svg" width="35%" onclick="window.location.href = './logs.php';">
                                </div>
                                <div class="col" style="text-align: left; padding-top:5%;">
                                <label>
                                        <h5>Historial de acciones</h5>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <!-- <div class="table-responsive cuadros-secc rounded-3"> -->
                    </div>
                    <div class="col" id="seccionDefault">
                        <img src="./LOGO_CU.svg" width="100%" height="100%">
                    </div>

                    <div class="col oculto" id="nuevoCliente">
                        <div class="cuadros-secc rounded-3 border border-3">
                            <form name="forma01" id="forma01">
                                <div class="row">
                                    <div class="col">
                                        <label for="id_empleado">ID Empleado</label>
                                        <input type="number" class="form-control" id="id_empleado" name="id_empleado" placeholder="Id del empleado">
                                    </div>
                                    <div class="col">
                                        <label for="tipo_admin">Puesto de usuario</label>
                                        <select class="form-control" id="tipo_admin" name="tipo_admin">
                                            <option selected>Seleccionar</option>
                                            <option value="1">Administrador</option>
                                            <option value="2">Recepcionista</option>
                                            <option value="3">Terapeuta</option>
                                            <option value="4">Recursos Humanos</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col">
                                        <div class="form-group">
                                            <label for="usuario">Usuario</label>
                                            <input type="text" class="form-control" id="usuario" name="usuario" placeholder="Usuario">
                                        </div>
                                    </div>
                                    <br>
                                    <div class="col">
                                        <div class="form-group">
                                            <label for="password">Contraseña</label>

                                            <input type="text" class="form-control" id="password" name="password" placeholder="Contraseña">
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <br>
                                <div class="container">
                                    <div class="row">
                                        <div class="col order-last">
                                        </div>
                                        <div class="col">
                                            <button class="btn btn-outline-success" style="width: 300px;" onclick="if(!agregarDatos()) return false;">Guardar nuevo usuario</button>
                                        </div>
                                        <div class="col order-first">
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col oculto" id="formCorrecto">
                        <div class="cuadros-secc rounded-3 border border-3" style="text-align: center;">
                            <div class="alert alert-success" role="alert">
                                <img src="./sgv/correcto_2.svg" width="55%" height="55%">
                                <h3>NUEVO USUARIO AGREGADO</h3>
                            </div>
                        </div>
                    </div>
                    <div class="col oculto" id="adeudoCliente">

                        <div class="cuadros-secc rounded-3 border border-3">
                            <form name="forma01">
                                <div class="row">
                                    <div class="col">
                                        <input type="number" class="form-control" id="id_usuario" nombre="id_usuario" placeholder="Id del cliente">
                                    </div>
                                </div>
                                <br>
                                <div class="table-responsive-lg">
                                    <table class="table">
                                        <div class="row">
                                            <div class="col" style="text-align:center;">
                                                <button type="submit" class="btn btn-outline-danger" style="width: 200px;" onclick="if(!asignarBaja()) return false;">Asignar baja</button>
                                            </div>
                                            <div class="col" style="text-align:center;">
                                                <button type="submit" class="btn btn-outline-success" style="width: 200px;" onclick="if(!quitarBaja()) return false;">Quitar baja</button>
                                            </div>
                                    </table>
                                </div>
                            </form>
                            <!-- tabla -->

                            <!-- fin tabla -->
                        </div>
                        <div class="cuadros-secc rounded-3 border border-3">
                            <div id="tabla_bajas">
                                <?php include("./listarUsuarios.php"); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col oculto" id="actualizarCliente">
                        <div class="cuadros-secc rounded-3 border border-3">
                            <div class="row">
                                <div class="col">
                                    <input type="number" class="form-control" id="id_usuario_act" name="id_usuario_act" placeholder="Id del cliente">
                                </div>
                            </div>
                            <br>
                            <div class="container">
                                <div class="row">
                                    <div class="col">
                                    </div>
                                    <div class="col">
                                    </div>
                                    <div class="col">
                                    </div>
                                    <div class="col">
                                        <button type="button" class="btn btn-outline-success" style="width: 300px;" onclick="cargarDatosAct();">Cargar registro de cliente</button>
                                    </div>
                                    <div class="col">
                                    </div>
                                    <div class="col">
                                    </div>
                                    <div class="col">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="cuadros-secc rounded-3 border border-3">
                            <div id="tabla_actualizar">
                                <?php include("./listarUsuariosAct.php"); ?>
                            </div>
                        </div>
                        <!-- Modal -->
                        <div class="modal fade" id="modalActualizar" tabindex="-1" role="dialog" aria-labelledby="modalActualizarLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="modalActualizarLabel">Actualizar Datos</h5>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row">
                                            <div class="row">
                                                <div class="col">
                                                    <!-- <input type="hidden" name="id_usuario" id="id_usuario"> -->
                                                    <label for="id_empleado_act">ID Empleado</label>

                                                    <input type="number" class="form-control" id="id_empleado_act" name="id_empleado_act" placeholder="Id del empleado">
                                                </div>
                                                <div class="col">
                                                    <label for="tipo_admin_act">Puesto de usuario</label>
                                                    <select class="form-control" id="tipo_admin_act" name="tipo_admin_act">
                                                        <option>Seleccionar</option>
                                                        <option value="1">Administrador</option>
                                                        <option value="2">Recepcionista</option>
                                                        <option value="3">Terapeuta</option>
                                                        <option value="4">Recursos Humanos</option>

                                                    </select>

                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col">
                                                    <div class="form-group">
                                                        <label for="usuario">Usuario</label>

                                                        <input type="text" class="form-control" id="usuario_act" name="usuario_act" placeholder="Usuario">

                                                    </div>
                                                </div>

                                                <!-- col -->
                                                <br>
                                                <div class="col">
                                                    <div class="form-group">
                                                        <label for="password">Contraseña</label>

                                                        <input type="text" class="form-control" id="password_act" name="password_act" placeholder="Contraseña">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-danger" onclick="cerrarModal()">Cancelar</button>
                                            <button type="button" class="btn btn-primary" onclick="actualizarDatos()">Guardar cambios</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="col oculto" id="mostrarCliente">
                        <div class="cuadros-secc rounded-3 border border-3">
                            <div id="tabla_mostrar">
                                <?php include("./listarUsuariosInfo.php"); ?>
                            </div>
                        </div>
                    </div>
            </main>
        </div>
    </div>

    <script src="./js/bootstrap.js" crossorigin="anonymous"></script>
    <script src="./js/active.js"></script>
</body>

</html>