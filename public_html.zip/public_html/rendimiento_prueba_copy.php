<?php
session_start();
// require './funciones/conecta.php';
if (!$_SESSION['idUsuario']) {
    header("Location: login.php");
} else {
    $idUsuarioIndex = $_SESSION['idUsuario'];
    $empleadoIndex = $_SESSION['idEmpleado'];
    $usuarioIndex = $_SESSION['usuario'];
    $tipoAdminIndex = $_SESSION['tipoAdmin'];
    $dadoBajaIndex = $_SESSION['dadoBaja'];
}
?>
<html lang="es">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <title>Administración</title>
    <script src="./js/jquery-3.6.0.min.js"></script>
    <link href="./css/jquery.dataTables.min.css" type="text/css" rel="stylesheet">
    <script type="text/javascript" src="./js/jquery.dataTables.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.css"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.bundle.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.css" rel="stylesheet">
    <!-- Bootstrap core CSS -->
    <link href="./css/bootstrap.css" rel="stylesheet" crossorigin="anonymous">
    <style>
        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }
    </style>
    <!-- Custom styles for this template -->
    <link href="./css/dashboard.css" rel="stylesheet">
    
    <style type="text/css">
        /* Chart.js */

        @keyframes chartjs-render-animation {
            from {
                opacity: .99
            }

            to {
                opacity: 1
            }
        }

        .chartjs-render-monitor {
            animation: chartjs-render-animation 1ms
        }

        .chartjs-size-monitor,
        .chartjs-size-monitor-expand,
        .chartjs-size-monitor-shrink {
            position: absolute;
            direction: ltr;
            left: 0;
            top: 0;
            right: 0;
            bottom: 0;
            overflow: hidden;
            pointer-events: none;
            visibility: hidden;
            z-index: -1
        }

        .chartjs-size-monitor-expand>div {
            position: absolute;
            width: 1000000px;
            height: 1000000px;
            left: 0;
            top: 0
        }

        .chartjs-size-monitor-shrink>div {
            position: absolute;
            width: 200%;
            height: 200%;
            left: 0;
            top: 0
        }

        .oculto {
            display: none;
        }

        .cuadros {
            border: 1px solid grey;
            /* border: 2.5px inset #E5E8E8; */
            border-radius: 100%;
            padding: 15px;
            -webkit-box-shadow: 0px 10px 13px -7px #000000, 5px 5px 15px 5px rgba(0, 0, 0, 0);
            box-shadow: 0px 10px 13px -7px #000000, 5px 5px 15px 5px rgba(0, 0, 0, 0);
        }
    </style>
</head>

<body>
    <?php include("./navbar/navbar.php"); ?>
    <div class="container-fluid">
        <div class="row">
            <?php include("./navbar/navbar_seccion.php"); ?>

            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Panel de administración - Gerencia</h1>
                </div>
                <div class="row">
                    <div class="col col-md-2" style="border: 1px solid black;">
                        <div class="row " style="border: 1px solid red;">
                            <div class="col cuadros" style="text-align: center;">
                                <input type="image" id="mostrarDatos" name="mostrarDatos" src="./sgv/info_empleado.svg" width="40%" onclick="mostrarInfoEmp();">
                                <label for="mostrarDatos">
                                    <h5>Información</h5>
                                </label>
                            </div>
                        </div>
                        <br>
                        <div class="row" style="border: 1px solid red;">
                            <div class="col cuadros" style="text-align: center;">
                                <input type="image" id="mostrarDatos" name="mostrarDatos" src="./sgv/info_empleado.svg" width="40%" onclick="mostrarInfoEmp();">
                                <label for="mostrarDatos">
                                    <h5>Información</h5>
                                </label>
                            </div>
                        </div>
                        <br>
                        <div class="row" style="border: 1px solid red;">
                            <div class="col cuadros" style="text-align: center;">
                                <input type="image" id="mostrarDatos" name="mostrarDatos" src="./sgv/info_empleado.svg" width="40%" onclick="mostrarInfoEmp();">
                                <label for="mostrarDatos">
                                    <h5>Información</h5>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="col " style="border: 1px solid yellow;">
                        <div class="row" style="border: 1px solid red;">
                            <div class="input-group">
                                <span class="input-group-text">IDE EMPLEADO</span>
                                <input type="number" id="id_empleado_datos" name="id_empleado_datos" class="form-control">
                                <span class="input-group-text">De</span>
                                <input type="date" id="laborar_inicio" name="laborar_inicio" class="form-control">
                                <span class="input-group-text">a</span>
                                <input type="date" id="laborar_fin" name="laborar_fin" class="form-control">
                                <button type="submit" class="btn btn-outline-secondary" onclick="enviar1();">Cargar datos</button>
                            </div>
                        </div>
                        <div class="col-lg-6" style="border: 1px solid blue;">
                            <div class="row" style="border: 1px solid red;" >
                                <div>
                                    <canvas id="myChart" width="100" height="100"></canvas>
                                </div>

                            </div>
                        </div>

                    </div>

            </main>
        </div>
    </div>
    <script>
        
        $(document).ready(function() {
            $('#myTable').DataTable({
                "lengthMenu": [
                    [4, 25, 50, -1],
                    [4, 25, 50, "All"]
                ],
                // "paging": false,
                "info": false
            });
        });
        var ctx = document.getElementById('myChart');
        var ctx = document.getElementById('myChart').getContext('2d');
        var ctx = $('#myChart');
        var ctx = 'myChart';
        var ctx = document.getElementById('myChart');
        var myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Pacientes dados de alta', 'Número de consultas', 'Niños consultados', 'Parejas consultadas'],
                datasets: [{
                    label: 'Rendimiento',
                    data: [12, 29, 3, 5],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(255, 159, 64, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                }
            }
        });
    </script>
    <script src="./js/bootstrap.js" crossorigin="anonymous"></script>
    <script src="./js/jquery-3.6.0.min.js"></script>
</body>

</html>