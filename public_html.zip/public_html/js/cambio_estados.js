// $("li").click(function() {
//     var myClass = $(this).attr("class");
//     alert(myClass);
// });

// $(this).click(function() {
//     $("a.nav-link").toggleClass("active");
// });