<?php
session_start();
if (!isset($_SESSION['idUsuario'])) {
    header("Location: login.php");
} else {
    $idUsuarioIndex = $_SESSION['idUsuario'];
    $empleadoIndex = $_SESSION['idEmpleado'];
    $usuarioIndex = $_SESSION['usuario'];
    $tipoAdminIndex = $_SESSION['tipoAdmin'];
    $dadoBajaIndex = $_SESSION['dadoBaja'];
}
?>
<html lang="es">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <title>Administración</title>

    <!-- Bootstrap core CSS -->
    <script src="./js/jquery-3.6.0.min.js"></script>
    <link href="./css/bootstrap.css" rel="stylesheet" crossorigin="anonymous">
    <link href="./css/jquery.dataTables.min.css" type="text/css" rel="stylesheet">
    <script type="text/javascript" src="./js/jquery.dataTables.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js" integrity="sha512-TW5s0IT/IppJtu76UbysrBH9Hy/5X41OTAbQuffZFU6lQ1rdcLHzpU5BzVvr/YFykoiMYZVWlr/PX1mDcfM9Qg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.esm.min.js" integrity="sha512-SaY95UIbYlNfmc6tZOtqEWMyDHpIKJwXCPfDZNvgudlFZiJjMU3XJNrSnkVCL/3b7szsoU3hDXpUz6+TdLY1ag==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/helpers.esm.min.js" integrity="sha512-urWBnIv+F027G24xDNigjxvIuwnWlWy94W2yx77VkISKLzKSohOKOubMDhtEF6LZcEH7gctmNSpxDqIW/zMmUg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>


    <style>
        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }
    </style>


    <!-- Custom styles for this template -->
    <link href="./css/dashboard.css" rel="stylesheet">
    <style type="text/css">
        /* Chart.js */

        @keyframes chartjs-render-animation {
            from {
                opacity: .99
            }

            to {
                opacity: 1
            }
        }

        .chartjs-render-monitor {
            animation: chartjs-render-animation 1ms
        }

        .chartjs-size-monitor,
        .chartjs-size-monitor-expand,
        .chartjs-size-monitor-shrink {
            position: absolute;
            direction: ltr;
            left: 0;
            top: 0;
            right: 0;
            bottom: 0;
            overflow: hidden;
            pointer-events: none;
            visibility: hidden;
            z-index: -1
        }

        .chartjs-size-monitor-expand>div {
            position: absolute;
            width: 1000000px;
            height: 1000000px;
            left: 0;
            top: 0
        }

        .chartjs-size-monitor-shrink>div {
            position: absolute;
            width: 200%;
            height: 200%;
            left: 0;
            top: 0
        }

        .oculto {
            display: none;
        }


        label {
            display: inline-block;
        }

        .cuadros {
            border: 1px solid grey;
            border: 10.5px outset #E5E8E8;
            border-radius: 5%;
            padding: 15px;
        }

        .cuadros-secc {
            padding: 15px;
            -webkit-box-shadow: 0px 10px 13px -7px #000000, 5px 5px 15px 5px rgba(0, 0, 0, 0);
            box-shadow: 0px 10px 13px -7px #000000, 5px 5px 15px 5px rgba(0, 0, 0, 0);
        }

        .datosCargados {
            border: 2.5px solid #E5E8E8;
            background-color: #F4F6F7;
            padding: 0.375rem 0.75rem;
            font-size: 1rem;
            font-weight: 400;
            line-height: 1.5;
        }
    </style>
    <script>
        $(document).ready(function() {
            $('#myTable').DataTable({
                "lengthMenu": [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
                // "paging": false,
                "info": false
            });
        });

        function enviar1() {
            var id_empleado = $('#id_empleado_datos').val();
            var fecha_inicio = $('#fecha_inicio').val();
            var fecha_fin = $('#fecha_fin').val();
            if (id_empleado != '' && fecha_inicio != '' && fecha_fin != '') {
                $.ajax({
                    url: './funciones/obtenerGrafica.php',
                    type: 'post',
                    data: 'id_empleado=' + id_empleado + '&fecha_inicio=' + fecha_inicio + '&fecha_fin=' + fecha_fin,
                    success: function(res) {
                        if ($.trim(res) != '0') {
                            var datos = $.trim(res).split("|");
                            // alert($.trim(res));
                            $("#graficaEmpleado").removeClass("oculto");
                            $("#seccionDefault").addClass("oculto");
                            // $("#graficaEmpleado").load(location.href + " #graficaEmpleado");
                            if (window.grafica) {
                                window.grafica.clear();
                                window.grafica.destroy();
                            }
                            window.grafica = cargarGrafica(0, datos[0], datos[1], datos[2]);
                        } else {
                            alert('No existen datos');
                        }
                        return true;
                    },
                    error: function(res) {
                        console.log(res);
                        alert('Error al conectar al servidor...');
                        return false;
                    }
                });
            } else {
                alert("Inserta datos completos");
                return false;
            }
        }

        function cargarGrafica(val1, val2, val3, val4) {
            const ctx = document.getElementById('myChart');
            const myChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: ['Pacientes dados de alta', 'Número de consultas', 'Niños consultados', 'Parejas consultadas'],
                    datasets: [{
                        label: 'Rendimiento',
                        data: [val1, val2, val3, val4],
                        backgroundColor: [
                            'rgba(255, 206, 86, 0.2)',
                            'rgba(75, 192, 192, 0.2)',
                            'rgba(153, 102, 255, 0.2)',
                            'rgba(255, 159, 64, 0.2)'
                        ],
                        borderColor: [
                            'rgba(255, 206, 86, 1)',
                            'rgba(75, 192, 192, 1)',
                            'rgba(153, 102, 255, 1)',
                            'rgba(255, 159, 64, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
            return myChart;
        }
    </script>

</head>

<body>

    <?php include("./navbar/navbar.php"); ?>

    <div class="container-fluid">
        <div class="row">
            <?php include("./navbar/navbar_seccion.php"); ?>
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Panel de administración - Gerencia</h1>
                </div>
            </main>
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <!-- Modal -->
                <div class="row">
                <div class="cuadros-secc rounded-3 border border-3">
                    <div class="input-group">
                        <span class="input-group-text">IDE EMPLEADO</span>
                        <input type="number" id="id_empleado_datos" name="id_empleado_datos" class="form-control">
                        <span class="input-group-text">De</span>
                        <input type="date" id="fecha_inicio" name="fecha_inicio" class="form-control">
                        <span class="input-group-text">a</span>
                        <input type="date" id="fecha_fin" name="fecha_fin" class="form-control">
                        <button type="submit" class="btn btn-outline-secondary" onclick="enviar1();">Cargar datos</button>
                        
                    </div>
                </div>    
                                
                </div>
                <br>
                <div class="row">
                    <div class="col">
                        <br>
                        <div class="table-responsive">
                            <table class="table table-bordered" id="myTable">
                                <thead>
                                    <tr>
                                        <th scope="col">IDE</th>
                                        <th scope="col">LISTA DE TERAPEUTAS</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    include('./funciones/conecta.php');
                                    $con = conecta();
                                    $sql = "SELECT * FROM `empleados`";
                                    // Check for errors
                                    if (mysqli_connect_errno()) {
                                        echo mysqli_connect_error();
                                    }
                                    $result = $con->query($sql);
                                    if ($result) {

                                        while ($row = $result->fetch_assoc()) {
                                            if($row["tipo_puesto"]==3){
                                    ?>

                                            <tr>
                                                <td><?php echo $row["id_empleado"]; ?></td>
                                                <td><?php echo $row["nombre"] . ' ' . $row["apellido"]; ?></td>                                            
                                            </tr>
                                    <?php
                                            }
                                        }
                                        $result->close();
                                        $con->next_result();
                                    }
                                    $con->close();
                                    ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="col" id="seccionDefault">
                        <img src="./LOGO_CU.svg" width="100%" height="100%">
                    </div>
                    <div class="col oculto" id="graficaEmpleado">
                <div class="rounded-3 border border-3">
                                    
                        <canvas id="myChart" width="100" height="100"></canvas>
                        <br>
                        </div>
                    </div>
                </div>

            </main>
        </div>
    </div>
    <script src="./js/bootstrap.js" crossorigin="anonymous"></script>
    <script src="./js/active.js"></script>
</body>

</html>